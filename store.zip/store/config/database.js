import { Sequelize, DataTypes } from 'sequelize';

export const sequelize = new Sequelize('store_api', 'root', '', {
  host: 'localhost',
  dialect: 'mysql',
  logging: false
});

export default sequelize;