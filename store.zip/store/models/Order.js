/*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
  // Firebase doesn't require predefined models.
  // Use Firestore directly in controllers or create helper functions here.
  // Collection name: "order"

 import { DataTypes } from "sequelize";
import { sequelize } from "../config/db.js";

export const Order = sequelize.define("order", {
  UserId: { type: DataTypes.INTEGER, allowNull: false },
  TotalAmount: { type: DataTypes.DECIMAL(10, 2), allowNull: false },
  Status: { type: DataTypes.STRING, allowNull: false, defaultValue: "pending" },
  PaymentMethod: { type: DataTypes.STRING, allowNull: false },
  ShippingAddress: { type: DataTypes.TEXT, allowNull: false },
  Notes: { type: DataTypes.TEXT, allowNull: true }
});

export const insertOrder = async (data) => {
  return await Order.create(data);
};

export const selectAllOrders = async () => {
  return await Order.findAll();
};

export const selectOrderById = async (id) => {
  return await Order.findByPk(id);
};

export default Order;