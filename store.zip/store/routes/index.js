
  /*
    MIT License
    
    Copyright (c) 2025 Christian I. Cabrera || XianFire Framework
    Mindoro State University - Philippines

    Permission is hereby granted, free of charge, to any person obtaining a copy
    of this software and associated documentation files (the "Software"), to deal
    in the Software without restriction, including without limitation the rights
    to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
    copies of the Software, and to permit persons to whom the Software is
    furnished to do so, subject to the following conditions:

    The above copyright notice and this permission notice shall be included in all
    copies or substantial portions of the Software.

    THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
    IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
    FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
    AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
    LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
    SOFTWARE.
    */
    
import express from "express";
import { homePage } from "../controllers/homeController.js";
const router = express.Router();
router.get("/", homePage);



import UserController from '../controllers/userontroller.js';
import ProductController from '../controllers/productcontroller.js';
import CategoryController from '../controllers/categorycontroller.js';
import OrderController from '../controllers/ordercontroller.js';
import OrderItemController from '../controllers/orderitemcontroller.js';

export default (router) => {
  // Users
  router.post('/users', UserController.create);
  router.get('/users', UserController.getAll);
  router.get('/users/:id', UserController.getById);

  // Products
  router.post('/products', ProductController.create);
  router.get('/products', ProductController.getAll);
  router.get('/products/:id', ProductController.getById);

  // Categories
  router.post('/categories', CategoryController.create);
  router.get('/categories', CategoryController.getAll);
  router.get('/categories/:id', CategoryController.getById);

  // Orders
  router.post('/orders', OrderController.create);
  router.get('/orders', OrderController.getAll);
  router.get('/orders/:id', OrderController.getById);

  // Order Items
  router.post('/order-items', OrderItemController.create);
  router.get('/order-items', OrderItemController.getAll);
  router.get('/order-items/:id', OrderItemController.getById);
};